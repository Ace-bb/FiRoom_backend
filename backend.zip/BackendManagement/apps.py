from django.apps import AppConfig


class BackendmanagementConfig(AppConfig):
    name = 'BackendManagement'
