<template>
  <v-footer padless>
    <v-col class="text-right py-1" cols="12">
      <a
        target="_blank"
        href="https://ms-ase-2020.github.io/team-ai-virtual-try-on/"
      >
        <span>About</span>
      </a>
    </v-col>
  </v-footer>
</template>

<script>
export default {
  name: "MyFooter",
};
</script>

<style scoped>
a {
  text-decoration: none;
  font-size: 14px;
}
</style>